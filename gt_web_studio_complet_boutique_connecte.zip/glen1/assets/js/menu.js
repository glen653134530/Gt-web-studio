
function toggleMenu() {
  const menu = document.getElementById("nav-menu");
  menu.style.right = (menu.style.right === "0%") ? "-100%" : "0%";
}
