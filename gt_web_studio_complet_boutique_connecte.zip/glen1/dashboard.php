
<?php
session_start();
if (!isset($_SESSION['utilisateur'])) {
    header("Location: login.php");
    exit;
}
?>
<h1>Bienvenue, <?php echo htmlspecialchars($_SESSION['utilisateur']); ?> !</h1>
<p>Vous êtes connecté à votre tableau de bord.</p>
<a href="logout.php">Déconnexion</a>
