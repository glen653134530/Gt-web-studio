
<?php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $produit = $_POST['produit'] ?? '';
    $quantite = intval($_POST['quantite'] ?? 0);
    $utilisateur_id = intval($_POST['utilisateur_id'] ?? 0);

    if ($produit && $quantite > 0 && $utilisateur_id > 0) {
        $stmt = $pdo->prepare("INSERT INTO commandes (utilisateur_id, produit, quantite) VALUES (:utilisateur_id, :produit, :quantite)");
        $stmt->execute([
            ':utilisateur_id' => $utilisateur_id,
            ':produit' => $produit,
            ':quantite' => $quantite
        ]);
        echo "Commande enregistrée avec succès.";
    } else {
        echo "Champs invalides.";
    }
}
?>
<form method="POST">
    <input type="number" name="utilisateur_id" placeholder="ID Utilisateur" required><br>
    <input type="text" name="produit" placeholder="Produit" required><br>
    <input type="number" name="quantite" placeholder="Quantité" required><br>
    <button type="submit">Commander</button>
</form>
