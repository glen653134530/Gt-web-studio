
<?php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'] ?? '';
    $email = $_POST['email'] ?? '';
    $mot_de_passe = password_hash($_POST['mot_de_passe'] ?? '', PASSWORD_DEFAULT);

    if (!empty($nom) && !empty($email) && !empty($mot_de_passe)) {
        $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, email, mot_de_passe) VALUES (:nom, :email, :mot_de_passe)");
        $stmt->execute([
            ':nom' => $nom,
            ':email' => $email,
            ':mot_de_passe' => $mot_de_passe
        ]);
        echo "Utilisateur ajouté avec succès.";
    } else {
        echo "Tous les champs sont requis.";
    }
}
?>
<form method="POST">
    <input type="text" name="nom" placeholder="Nom" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="mot_de_passe" placeholder="Mot de passe" required><br>
    <button type="submit">Ajouter</button>
</form>
